import sys
import cv2
import numpy as np
import matplotlib.pyplot as plt

# from flask import Flask, render_template, request, redirect, Response
import flask as flk
import random, json
import os

# export PYTHONPATH=/usr/local/lib/python2.7/site-packages:$PYTHONPATH

app = flk.Flask(__name__)

count = 0
@app.route('/')
def output():
    # serve index template
    return flk.render_template('chrome-dino.html')

@app.route('/receiver', methods = ['POST'])
def worker():
    global count
    # read json + reply
    data = dict(flk.request.form)
    img_b64 = data['data'][0].split(',')[1]
    img = img_b64.decode('base64')
    pixarr = np.fromstring(img, np.uint8)
    img = cv2.imdecode(pixarr, cv2.IMREAD_UNCHANGED)

    if (count == 0):
        action = 'DOWN'
    elif (count%100):
        action = 'UP'
    else:
        action = 'RUNNING'

    count += 1

    # plt.imshow(img)
    # plt.show()

    return action

if __name__ == "__main__":
    app.run("0.0.0.0", "8000")
